const bcrypt = require("bcryptjs");

const jwt = require("jsonwebtoken");

const User = require("../models/User");

const registerUser = async (req, res) => {
    try {

        const { name, email, mobile, password } = req.body;

        // Check if email already exists
        const existingUser = await User.findOne({ email });

        if (existingUser) {
            return res.status(400).json({
                message: "User already exists"
            });
        }
        const hashedPassword = await bcrypt.hash(password, 10);
        // Create new user
        const newUser = await User.create({
            name,
            email,
            mobile,
            password: hashedPassword
        });

        res.status(201).json({
            message: "User registered successfully",
            user: newUser
        });

    } catch (error) {

        res.status(500).json({
            message: error.message
        });

    }
};

const loginUser = async (req, res) => {
    try {

        const { email, password } = req.body;

        // Find user
        const user = await User.findOne({ email });

        if (!user) {
            return res.status(400).json({
                message: "User not found"
            });
        }

        // Compare password
        const isMatch = await bcrypt.compare(password, user.password);

        if (!isMatch) {
            return res.status(400).json({
                message: "Invalid Password"
            });
        }

        // Generate JWT Token
        const token = jwt.sign(
            {
                id: user._id,
                email: user.email
            },
            process.env.JWT_SECRET,
            {
                expiresIn: "7d"
            }
        );

        // Send response
        res.status(200).json({
            message: "Login Successful",
            token,
            user: {
                id: user._id,
                name: user.name,
                email: user.email
            }
        });

    } catch (error) {

        res.status(500).json({
            message: error.message
        });

    }
};
const getProfile = async (req, res) => {
    try {

        const user = await User.findById(req.user.id).select("-password");

        if (!user) {
            return res.status(404).json({
                message: "User not found"
            });
        }

        res.status(200).json(user);

    } catch (error) {

        res.status(500).json({
            message: error.message
        });

    }
};
const updateProfile = async (req, res) => {

    try {

        const {
            name,
            mobile,
            gender,
            dob,
            city,
            state
        } = req.body;

        const user = await User.findByIdAndUpdate(

            req.user.id,

            {
                name,
                mobile,
                gender,
                dob,
                city,
                state
            },

            {
                new: true
            }

        ).select("-password");

        res.status(200).json({

            message: "Profile updated successfully.",

            user

        });

    }

    catch (error) {

        res.status(500).json({

            message: "Server Error"

        });

    }

};

module.exports = {
    registerUser,
    loginUser,
    getProfile,
    updateProfile
};