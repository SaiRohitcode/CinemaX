const Show = require("../models/Show");


const createShow = async (req, res) => {

    try {

        const {
            movie,
            theatre,
            screen,
            date,
            language,
            format,
            showTime
        } = req.body;

        if (
            !movie ||
            !theatre ||
            !screen ||
            !date ||
            !language ||
            !format ||
            !showTime
        ) {
            return res.status(400).json({
                success: false,
                message: "Please fill all required fields."
            });
        }

        const show = await Show.create(req.body);

        res.status(201).json({
            success: true,
            message: "Show created successfully.",
            show
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};


const getShows = async (req, res) => {

    try {

        const shows = await Show.find({ isActive: true })
            .populate("movie")
            .populate("theatre")
            .populate("screen")
            .sort({ date: 1 });

        res.status(200).json({
            success: true,
            count: shows.length,
            shows
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};


const getShow = async (req, res) => {

    try {

        const show = await Show.findById(req.params.id)
            .populate("movie")
            .populate("theatre")
            .populate("screen");

        if (!show) {
            return res.status(404).json({
                success: false,
                message: "Show not found."
            });
        }

        res.status(200).json({
            success: true,
            show
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};


const updateShow = async (req, res) => {

    try {

        const show = await Show.findById(req.params.id);

        if (!show) {
            return res.status(404).json({
                success: false,
                message: "Show not found."
            });
        }

        const updatedShow = await Show.findByIdAndUpdate(
            req.params.id,
            req.body,
            {
                new: true,
                runValidators: true
            }
        );

        res.status(200).json({
            success: true,
            message: "Show updated successfully.",
            show: updatedShow
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};

const deleteShow = async (req, res) => {

    try {

        const show = await Show.findById(req.params.id);

        if (!show) {
            return res.status(404).json({
                success: false,
                message: "Show not found."
            });
        }

        show.isActive = false;

        await show.save();

        res.status(200).json({
            success: true,
            message: "Show deleted successfully."
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};

module.exports = {
    createShow,
    getShows,
    getShow,
    updateShow,
    deleteShow
};