const express = require("express");
const router = express.Router();

const {
    createShow,
    getShows,
    getShow,
    updateShow,
    deleteShow
} = require("../controllers/showController");

const authMiddleware = require("../middleware/authMiddleware");

router.get("/", getShows);
router.get("/:id", getShow);

router.post("/", authMiddleware, createShow);
router.put("/:id", authMiddleware, updateShow);
router.delete("/:id", authMiddleware, deleteShow);

module.exports = router;