const Booking = require("../models/Booking");
const { v4: uuidv4 } = require("uuid");

// Create Booking
const createBooking = async (req, res) => {
    try {

        const {
            user,
            movieId,
            movieName,
            moviePoster,
            theatre,
            screen,
            language,
            format,
            date,
            day,
            showTime,
            seats,
            numberOfSeats,
            ticketPrice,
            convenienceFee,
            gst,
            totalPrice,
            paymentMethod
        } = req.body;

        if (
            !user ||
            !movieId ||
            !movieName ||
            !theatre ||
            !screen ||
            !language ||
            !date ||
            !day ||
            !showTime ||
            !seats ||
            seats.length === 0
        ) {
            return res.status(400).json({
                success: false,
                message: "Please fill all required fields."
            });
        }

        const bookedSeats = await Booking.find({
            theatre,
            screen,
            date,
            showTime,
            bookingStatus: "Confirmed",
            seats: { $in: seats }
        });

        if (bookedSeats.length > 0) {
            return res.status(400).json({
                success: false,
                message: "One or more selected seats are already booked."
            });
        }

        const booking = await Booking.create({
            user,
            movieId,
            movieName,
            moviePoster,
            theatre,
            screen,
            language,
            format,
            date,
            day,
            showTime,
            seats,
            numberOfSeats,
            ticketPrice,
            convenienceFee,
            gst,
            totalPrice,
            paymentMethod,
            bookingId: uuidv4()
        });

        res.status(201).json({
            success: true,
            message: "Booking confirmed successfully.",
            booking
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });

    }
};

// Get All Bookings
const getBookings = async (req, res) => {

    try {

        const bookings = await Booking.find()
            .populate("user")
            .sort({ bookedAt: -1 });

        res.status(200).json({
            success: true,
            count: bookings.length,
            bookings
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};

// Get Booking By ID
const getBooking = async (req, res) => {

    try {

        const booking = await Booking.findById(req.params.id)
            .populate("user");

        if (!booking) {
            return res.status(404).json({
                success: false,
                message: "Booking not found."
            });
        }

        res.status(200).json({
            success: true,
            booking
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};

// User Booking History
const getUserBookings = async (req, res) => {

    try {

        const bookings = await Booking.find({
            user: req.params.userId
        }).sort({
            bookedAt: -1
        });

        res.status(200).json({
            success: true,
            count: bookings.length,
            bookings
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};

// Cancel Ticket
const cancelBooking = async (req, res) => {

    try {

        const booking = await Booking.findById(req.params.id);

        if (!booking) {
            return res.status(404).json({
                success: false,
                message: "Booking not found."
            });
        }

        if (booking.bookingStatus === "Cancelled") {
            return res.status(400).json({
                success: false,
                message: "Booking already cancelled."
            });
        }

        booking.bookingStatus = "Cancelled";

        await booking.save();

        res.status(200).json({
            success: true,
            message: "Ticket cancelled successfully.",
            booking
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};

// Delete Booking
const deleteBooking = async (req, res) => {

    try {

        const booking = await Booking.findById(req.params.id);

        if (!booking) {
            return res.status(404).json({
                success: false,
                message: "Booking not found."
            });
        }

        await Booking.findByIdAndDelete(req.params.id);

        res.status(200).json({
            success: true,
            message: "Booking deleted successfully."
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};

module.exports = {
    createBooking,
    getBookings,
    getBooking,
    getUserBookings,
    cancelBooking,
    deleteBooking
};