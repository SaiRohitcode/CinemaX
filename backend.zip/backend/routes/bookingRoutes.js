const express = require("express");
const router = express.Router();

const {
    createBooking,
    getBookings,
    getBooking,
    getUserBookings,
    cancelBooking,
    deleteBooking
} = require("../controllers/bookingController");

const authMiddleware = require("../middleware/authMiddleware");

router.post("/", authMiddleware, createBooking);

router.get("/", authMiddleware, getBookings);

router.get("/:id", authMiddleware, getBooking);

router.get("/user/:userId", authMiddleware, getUserBookings);

router.put("/:id/cancel", authMiddleware, cancelBooking);

router.delete("/:id", authMiddleware, deleteBooking);

module.exports = router;