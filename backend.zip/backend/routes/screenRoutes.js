const express = require("express");
const router = express.Router();

const {
    createScreen,
    getScreens,
    getScreen,
    updateScreen,
    deleteScreen
} = require("../controllers/screenController");

const authMiddleware = require("../middleware/authMiddleware");

router.get("/", getScreens);
router.get("/:id", getScreen);

router.post("/", authMiddleware, createScreen);
router.put("/:id", authMiddleware, updateScreen);
router.delete("/:id", authMiddleware, deleteScreen);

module.exports = router;