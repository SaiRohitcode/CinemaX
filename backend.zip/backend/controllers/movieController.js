const Movie = require("../models/Movie");

// Get All Movies
const getMovies = async (req, res) => {

    try {

        const movies = await Movie.find();

        res.status(200).json(movies);

    } catch (error) {

        res.status(500).json({
            message: error.message
        });

    }
const Movie = require("../models/Movie");

const createMovie = async (req, res) => {
    try {

        const {
            title,
            description,
            genre,
            languages,
            formats,
            duration,
            releaseDate,
            poster
        } = req.body;

        if (
            !title ||
            !description ||
            !genre ||
            !languages ||
            !formats ||
            !duration ||
            !releaseDate ||
            !poster
        ) {
            return res.status(400).json({
                success: false,
                message: "Please fill all required fields."
            });
        }

        const existingMovie = await Movie.findOne({
            title: title.trim()
        });

        if (existingMovie) {
            return res.status(400).json({
                success: false,
                message: "Movie already exists."
            });
        }

        const movie = await Movie.create(req.body);

        res.status(201).json({
            success: true,
            message: "Movie created successfully.",
            movie
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });

    }
};

const getMovies = async (req, res) => {

    try {

        const movies = await Movie.find({
            isActive: true
        }).sort({
            createdAt: -1
        });

        res.status(200).json({
            success: true,
            count: movies.length,
            movies
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};

const getMovie = async (req, res) => {

    try {

        const movie = await Movie.findById(req.params.id);

        if (!movie) {
            return res.status(404).json({
                success: false,
                message: "Movie not found."
            });
        }

        res.status(200).json({
            success: true,
            movie
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};

const updateMovie = async (req, res) => {

    try {

        const movie = await Movie.findById(req.params.id);

        if (!movie) {
            return res.status(404).json({
                success: false,
                message: "Movie not found."
            });
        }

        const updatedMovie = await Movie.findByIdAndUpdate(
            req.params.id,
            req.body,
            {
                new: true,
                runValidators: true
            }
        );

        res.status(200).json({
            success: true,
            message: "Movie updated successfully.",
            movie: updatedMovie
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};

const deleteMovie = async (req, res) => {

    try {

        const movie = await Movie.findById(req.params.id);

        if (!movie) {
            return res.status(404).json({
                success: false,
                message: "Movie not found."
            });
        }

        movie.isActive = false;

        await movie.save();

        res.status(200).json({
            success: true,
            message: "Movie deleted successfully."
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });

    }

};

module.exports = {
    createMovie,
    getMovies,
    getMovie,
    updateMovie,
    deleteMovie
};
};

// Add Movie
const addMovie = async (req, res) => {

    try {

        const movie = await Movie.create(req.body);

        res.status(201).json({
            message: "Movie Added Successfully",
            movie
        });

    } catch (error) {

        res.status(500).json({
            message: error.message
        });

    }

};

module.exports = {
    getMovies,
    addMovie
};