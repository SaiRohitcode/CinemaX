const mongoose = require("mongoose");

const bookingSchema = new mongoose.Schema({

    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        required: true
    },

    movieId: {
        type: Number,
        required: true
    },

    movieName: {
        type: String,
        required: true
    },

    moviePoster: {
        type: String
    },

    theatre: {
        type: String,
        required: true
    },

    screen: {
        type: String,
        required: true
    },

    language: {
        type: String,
        required: true
    },

    format: {
        type: String,
        default: "2D"
    },

    date: {
        type: String,
        required: true
    },

    day: {
        type: String,
        required: true
    },

    showTime: {
        type: String,
        required: true
    },

    seats: [{
        type: String
    }],

    numberOfSeats: {
        type: Number,
        required: true
    },

    ticketPrice: {
        type: Number,
        required: true
    },

    convenienceFee: {
        type: Number,
        default: 40
    },

    gst: {
        type: Number,
        default: 18
    },

    totalPrice: {
        type: Number,
        required: true
    },

    paymentMethod: {
        type: String,
        default: "Online"
    },

    bookingStatus: {
        type: String,
        enum: ["Confirmed", "Cancelled"],
        default: "Confirmed"
    },

    bookingId: {
        type: String,
        unique: true
    },

    bookedAt: {
        type: Date,
        default: Date.now
    }

});

module.exports = mongoose.model("Booking", bookingSchema);