const mongoose = require("mongoose");

const SeatSchema = new mongoose.Schema({

    seatId: {
        type: String,
        required: true
    },

    row: {
        type: String,
        required: true
    },

    section: {
        type: String,
        required: true
    },
    number: {
        type: Number,
        required: true
    },

    price: {
        type: Number,
        required: true
    },

    isBlocked: {
        type: Boolean,
        default: false
    }

}, { _id: false });

const ScreenSchema = new mongoose.Schema({

    theatre: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Theatre",
        required: true
    },

    name: {
        type: String,
        required: true
    },

    screenType: {
        type: String,
        enum: ["2D", "3D", "IMAX", "4DX", "Dolby Atmos"],
        required: true
    },

    totalSeats: {
        type: Number,
        required: true
    },

    seats: [SeatSchema],

    isActive: {
        type: Boolean,
        default: true
    }

}, {
    timestamps: true
});

module.exports = mongoose.model("Screen", ScreenSchema);