const express = require("express");
const router = express.Router();

const {
    createTheatre,
    getTheatres,
    getTheatre,
    updateTheatre,
    deleteTheatre
} = require("../controllers/theatreController");

const authMiddleware = require("../middleware/authMiddleware");

router.post("/", authMiddleware, createTheatre);
router.get("/", getTheatres);
router.get("/:id", getTheatre);
router.put("/:id", authMiddleware, updateTheatre);
router.delete("/:id", authMiddleware, deleteTheatre);

module.exports = router;