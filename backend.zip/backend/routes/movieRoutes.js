const express = require("express");
const router = express.Router();

const {
    createMovie,
    getMovies,
    getMovie,
    updateMovie,
    deleteMovie
} = require("../controllers/movieController");

const authMiddleware = require("../middleware/authMiddleware");

// Admin
router.post("/", authMiddleware, createMovie);
router.put("/:id", authMiddleware, updateMovie);
router.delete("/:id", authMiddleware, deleteMovie);

// Public
router.get("/", getMovies);
router.get("/:id", getMovie);

module.exports = router;